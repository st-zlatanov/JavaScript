# Spaceship workshop

## Installation

1. Install NodeJS
2. Run ```npm install http-server -g``` in the command line
3. Run ```http-server``` inside the root folder of the project
4. Open http://localhost:8080/index.html in Google Chrome (port may change due availability, observe the console output to verify it)
